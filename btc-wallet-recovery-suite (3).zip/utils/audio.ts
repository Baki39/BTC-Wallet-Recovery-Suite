/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

// Sound effects have been removed. These functions are now no-ops 
// to prevent any errors from lingering calls.
export const playAiSound = () => {};
export const stopAiSound = () => {};
