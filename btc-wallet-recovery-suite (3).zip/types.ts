/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

export enum RecoveryMode {
  HUB = 'hub',
  SELECT = 'select',
  PASSWORD = 'password',
  SEED = 'seed',
  GUIDE = 'guide',
  DECRYPT = 'decrypt',
  EDUCATION = 'education',
  INVESTIGATE = 'investigate',
  SCANNER = 'scanner',
}

export enum MessageSender {
  USER = 'user',
  MODEL = 'model',
  SYSTEM = 'system',
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: MessageSender;
  isLoading?: boolean;
}

// Types for AI Chain Investigator
export interface RecoveryStep {
    title: string;
    description: string;
}

export interface TimelineEvent {
    date: string;
    description: string;
    type: string;
}

export interface AnalysisResult {
    summary: string;
    profile: string;
    walletOriginGuess: string;
    recoverySteps: RecoveryStep[];
    timelineEvents: TimelineEvent[];
}

// Types for Recovery Hub
export interface LoadedFile {
  name: string;
  size: number;
}

export interface SavedSeedPhrase {
  id: string;
  words: string[];
}

export interface PinnedAddress {
  id: string;
  address: string;
}

export interface RecoveryData {
  file: LoadedFile | null;
  seedPhrases: SavedSeedPhrase[];
  pinnedAddresses: PinnedAddress[];
  notes: string;
}

// Types for Advanced Features
export interface DecryptionProgress {
    status: 'idle' | 'generating' | 'running' | 'finished';
    log: string[];
}

export interface SeedForensics {
    correctedPhrase?: string;
    wordSuggestions?: string[];
    derivationPathInfo?: string;
}
