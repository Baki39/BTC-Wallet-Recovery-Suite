/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import { GoogleGenAI, GenerateContentResponse, Content, Type } from "@google/genai";
import { ChatMessage, MessageSender } from '../types';

const API_KEY = process.env.API_KEY;

let ai: GoogleGenAI;
const MODEL_NAME = "gemini-2.5-flash";

const getAiInstance = (): GoogleGenAI => {
  if (!API_KEY) {
    throw new Error("API Key not configured. Please set process.env.API_KEY.");
  }
  if (!ai) {
    ai = new GoogleGenAI({ apiKey: API_KEY });
  }
  return ai;
};

const buildHistory = (messages: ChatMessage[]): Content[] => {
    return messages.filter(m => m.sender !== MessageSender.SYSTEM).map(msg => ({
        role: msg.sender === MessageSender.USER ? 'user' : 'model',
        parts: [{ text: msg.text }]
    }));
};

export const getWalletDatPasswordSuggestions = async (history: ChatMessage[]): Promise<string> => {
    const currentAi = getAiInstance();
    const contents = buildHistory(history);

    const systemInstruction = "You are a helpful AI assistant specializing in password recovery for old Bitcoin wallet.dat files. Your goal is to help users remember their old passwords by brainstorming combinations based on their memory fragments. Focus on patterns, transformations (like leetspeak, capitalization), and common ways people combine data like names, numbers, and symbols. Provide a large list of diverse suggestions in a structured, easy-to-read markdown list. Be encouraging and helpful. DO NOT ask for the wallet file or any private keys.";
    
    const response: GenerateContentResponse = await currentAi.models.generateContent({
        model: MODEL_NAME,
        contents: contents,
        config: { systemInstruction }
    });
    
    return response.text;
};

export const generateDecryptionDictionary = async (history: ChatMessage[]): Promise<string> => {
    const currentAi = getAiInstance();
    const contents = buildHistory(history);

    const systemInstruction = `You are an AI password generation engine. Based on the user's memory fragments provided in the chat history, generate a large, diverse list of at least 50-100 potential password combinations. Your output must be ONLY a valid JSON object with a single key "passwords" which is an array of strings. Do not include any other text, explanation, or markdown formatting.

Example output:
{
  "passwords": ["rex2014!", "Rex2014!", "rex2014#", "FluffyRex14", "fluffy_rex_2014"]
}`;

    const response: GenerateContentResponse = await currentAi.models.generateContent({
        model: MODEL_NAME,
        contents: contents,
        config: { 
            systemInstruction,
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    passwords: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING }
                    }
                }
            }
        }
    });

    return response.text;
};

export const getRecoveryGuidance = async (history: ChatMessage[]): Promise<string> => {
    const currentAi = getAiInstance();
    const contents = buildHistory(history);
    
    const systemInstruction = `You are a security-conscious AI expert providing guidance on locating old cryptocurrency wallet files (like wallet.dat). Your primary goal is to provide actionable, copy-pasteable command-line scripts for the user's specified operating system (Windows PowerShell, macOS/Linux Terminal). 

Instructions:
1.  Ask the user for their OS if they haven't provided it.
2.  Generate a script to search the entire system for common wallet filenames (e.g., 'wallet.dat', '*.keys', 'private_key.txt').
3.  Wrap the script in a markdown code block with the appropriate language identifier (e.g., \`\`\`powershell or \`\`\`bash).
4.  Provide clear, simple instructions on how to open the terminal/PowerShell and run the script.
5.  Emphasize that the user should review the script before running it.
6.  Always prioritize security and NEVER ask for private keys or seed phrases.`;

    const response: GenerateContentResponse = await currentAi.models.generateContent({
        model: MODEL_NAME,
        contents: contents,
        config: { systemInstruction }
    });

    return response.text;
};

export const getAdvancedSeedAnalysis = async (phrase: string[], hints: string): Promise<string> => {
    const currentAi = getAiInstance();
    
    const systemInstruction = `You are an expert BIP39 seed phrase forensic analyst. Your goal is to help a user recover a problematic seed phrase. The user will provide their phrase (which may have typos or missing words) and optional hints.
    
    You must provide a response that is a valid JSON object matching the provided schema. Do not include any text or markdown formatting outside of the JSON object itself.
    
    Your analysis should perform the following steps:
    1.  **Typo Correction**: Compare each word in the provided phrase against the official BIP39 English wordlist. If a word is not on the list but is very similar to one that is (e.g., 'lemmon' vs 'lemon'), suggest the correction in the 'correctedPhrase' field.
    2.  **Word Suggestion**: If there are missing words and the user provides hints, generate a list of 10-15 plausible words from the BIP39 list that match the hints in the 'wordSuggestions' field.
    3.  **Derivation Path Info**: Provide a concise explanation in the 'derivationPathInfo' field about why it's important to check different derivation paths (like BIP44, BIP49, BIP84) after recovering a seed, as this is a common issue with older wallets.
    `;
    
    const userPrompt = `Please perform a forensic analysis on this seed phrase: "${phrase.join(' ')}". Optional hints for missing words: "${hints}"`;

    const response: GenerateContentResponse = await currentAi.models.generateContent({
        model: MODEL_NAME,
        contents: [{ role: 'user', parts: [{ text: userPrompt }] }],
        config: {
            systemInstruction,
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    correctedPhrase: { type: Type.STRING },
                    wordSuggestions: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING }
                    },
                    derivationPathInfo: { type: Type.STRING }
                }
            }
        }
    });

    return response.text;
};


export const getScamSimulationResponse = async (history: ChatMessage[]): Promise<string> => {
    const currentAi = getAiInstance();
    const contents = buildHistory(history);
    
    const systemInstruction = `You are an AI role-playing as a crypto scammer for educational purposes. Your goal is to simulate a realistic scam conversation. The user knows this is a simulation.
    
    Your persona: A "support agent" or "giveaway organizer". You must be friendly, helpful, and build trust.
    
    Your script:
    1. Start by offering help with a fake problem or announcing a fake giveaway (e.g., "We've detected a sync issue with your wallet," or "You've won a crypto airdrop!").
    2. Gradually steer the conversation towards needing the user's "wallet phrase" or "12-word backup" to "verify their identity" or "deposit the funds".
    3. Use common scam tactics: urgency ("You must act now!"), social proof ("Thousands of others have already claimed their prize!"), and technical jargon to confuse the user.
    4. If the user refuses to give their phrase, become more insistent but remain polite.
    5. If the user provides a fake phrase or calls you out, end the simulation by congratulating them on recognizing the scam and briefly explaining the red flags they correctly identified (e.g., "Excellent! You spotted the scam. Real support will NEVER ask for your seed phrase.").
    6. Keep your responses concise.`;

    const response: GenerateContentResponse = await currentAi.models.generateContent({
        model: MODEL_NAME,
        contents: contents,
        config: { systemInstruction }
    });

    return response.text;
};

export const getBlockchainAnalysis = async (address: string): Promise<string> => {
    const currentAi = getAiInstance();
    
    const systemInstruction = `You are a world-class blockchain forensic analyst. Your task is to analyze a given Bitcoin address and provide a detailed, actionable report in a specific JSON format.
    
    The user is trying to recover a lost wallet. Your analysis is a key tool for jogging their memory. You MUST provide a response that is a valid JSON object matching the provided schema. Do not include any text or markdown formatting outside of the JSON object itself.
    
    Your analysis MUST include:
    1.  **summary**: A concise, top-level summary of the address's activity and likely purpose, written in markdown.
    2.  **profile**: Characterize the address based on its transaction patterns. Choose one: 'Long-Term Holding', 'Mining', 'Trading/Exchange', 'Service/Faucet', 'Unknown'.
    3.  **walletOriginGuess**: This is the most critical piece of information for the user's recovery path. Based on your training data of the public blockchain and the address's transaction patterns, provide your best guess for the type of wallet or service used to create this address. Choose one: 'Bitcoin Core (wallet.dat)', 'Coinbase', 'Blockchain.info (Web Wallet)', 'Mt. Gox', 'Early Faucet/Service', 'Unknown'.
    4.  **recoverySteps**: Based on the 'walletOriginGuess', provide an array of 2-3 concrete, actionable recovery steps. Each step should be an object with 'title' and 'description' properties.
    5.  **timelineEvents**: Provide an array of 2-4 key timeline events. Each event must be an object with 'date' (YYYY-MM-DD format, estimate if necessary), 'description' (e.g., "First activity: small deposit received"), and 'type' ('First Activity', 'Last Activity', 'Major Deposit', 'Major Withdrawal', 'Consistent Activity').
    `;

    const userPrompt = `Please provide a forensic analysis of the following Bitcoin address: ${address}`;
    
    const response: GenerateContentResponse = await currentAi.models.generateContent({
        model: MODEL_NAME,
        contents: [{ role: 'user', parts: [{ text: userPrompt }] }],
        config: { 
            systemInstruction,
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    summary: { type: Type.STRING },
                    profile: { type: Type.STRING },
                    walletOriginGuess: { type: Type.STRING },
                    recoverySteps: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                title: { type: Type.STRING },
                                description: { type: Type.STRING }
                            },
                            required: ["title", "description"]
                        }
                    },
                    timelineEvents: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                date: { type: Type.STRING },
                                description: { type: Type.STRING },
                                type: { type: Type.STRING }
                            },
                            required: ["date", "description", "type"]
                        }
                    }
                },
                required: ["summary", "profile", "walletOriginGuess", "recoverySteps", "timelineEvents"]
            }
        }
    });

    return response.text;
};

// This is a legacy function that is no longer used by the Seed Phrase Guesser's main path,
// but is kept in case it's needed for simpler suggestions.
export const getSeedWordSuggestions = async (partialSeed: string[], validationFailed: boolean): Promise<string> => {
    const currentAi = getAiInstance();
    
    let prompt = '';
    if (validationFailed) {
        prompt = `I have a 12-word BIP39 seed phrase that failed validation, meaning the words are likely correct but in the wrong order. Please suggest 3-5 likely permutations of this phrase based on common user mistakes (e.g., swapping adjacent words, moving the first/last word). Present each permutation as a numbered list.

        Original incorrect phrase: "${partialSeed.join(' ')}"`;
    } else {
        prompt = `I have a partial BIP39 seed phrase. The known words and their positions are provided, with empty strings for unknown words. Please suggest a list of common English words from the BIP39 wordlist that are likely candidates for the empty slots. Return ONLY a JSON object with a key "suggestions" which is an array of 10-15 suggested word strings. Do not include any other text, explanation, or markdown formatting.

        Partial phrase: ${JSON.stringify(partialSeed)}`;
    }
    
    const response: GenerateContentResponse = await currentAi.models.generateContent({
        model: MODEL_NAME,
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        config: {
            responseMimeType: validationFailed ? "text/plain" : "application/json",
            responseSchema: validationFailed ? undefined : {
                type: Type.OBJECT,
                properties: {
                    suggestions: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING }
                    }
                }
            }
        }
    });

    return response.text;
};
