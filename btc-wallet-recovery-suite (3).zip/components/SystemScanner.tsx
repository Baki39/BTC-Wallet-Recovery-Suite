/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useRef } from 'react';
import { Download, Laptop, Terminal, UploadCloud, CheckCircle, ArrowRight } from 'lucide-react';
import { RecoveryData, RecoveryMode, PinnedAddress } from '../types';

interface SystemScannerProps {
    recoveryData: RecoveryData;
    onUpdateData: (data: RecoveryData) => void;
    onNavigate: (mode: RecoveryMode) => void;
}

const SystemScanner: React.FC<SystemScannerProps> = ({ recoveryData, onUpdateData, onNavigate }) => {
    const [scanState, setScanState] = useState<'idle' | 'downloaded' | 'uploaded'>('idle');
    const scanResultsInputRef = useRef<HTMLInputElement>(null);

    const createAndDownloadFile = (filename: string, content: string) => {
        const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        setScanState('downloaded');
    };

    const handleDownloadWindows = () => {
        const scriptContent = `@echo off
echo Searching for wallet files... This may take a while.
setlocal
set "OUTFILE=%USERPROFILE%\\Desktop\\wallet_scan_results.txt"
echo Found Wallet Files > %OUTFILE%
echo ===================== >> %OUTFILE%
for %%d in (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
    if exist %%d:\\ (
        echo. >> %OUTFILE%
        echo Searching on drive %%d: >> %OUTFILE%
        dir %%d:\\wallet.dat /s /b >> %OUTFILE% 2>nul
        dir %%d:\\*.keys /s /b >> %OUTFILE% 2>nul
        dir %%d:\\*.wallet /s /b >> %OUTFILE% 2>nul
        dir %%d:\\private_key* /s /b >> %OUTFILE% 2>nul
    )
)
endlocal
echo.
echo Scan complete. Results saved to wallet_scan_results.txt on your Desktop.
pause
`;
        createAndDownloadFile('scan_wallets.bat', scriptContent);
    };

    const handleDownloadMacLinux = () => {
        const scriptContent = `#!/bin/bash
echo "Searching for wallet files... This may take a while."
RESULTS_FILE=~/Desktop/wallet_scan_results.txt
echo "Found Wallet Files" > "$RESULTS_FILE"
echo "=====================" >> "$RESULTS_FILE"
find / -name "wallet.dat" -o -name "*.keys" -o -name "*.wallet" -o -name "private_key*" 2>/dev/null >> "$RESULTS_FILE"
echo "Scan complete. Results saved to wallet_scan_results.txt on your Desktop."
`;
        createAndDownloadFile('scan_wallets.sh', scriptContent);
    };
    
    const handleScanResultsUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            const file = e.target.files[0];
            const reader = new FileReader();
            reader.onload = (event) => {
                const content = event.target?.result as string;
                if (content) {
                    const paths = content.split('\n')
                        .map(line => line.trim())
                        .filter(line => (line.includes('\\') || line.includes('/')) && !line.startsWith("Searching on drive"));
                    
                    const newAddresses: PinnedAddress[] = paths.map(path => ({
                        id: `path-${path}-${Date.now()}`,
                        address: path,
                    }));
    
                    const existingPaths = new Set(recoveryData.pinnedAddresses.map(p => p.address));
                    const uniqueNewAddresses = newAddresses.filter(addr => !existingPaths.has(addr.address));
    
                    onUpdateData({
                        ...recoveryData,
                        pinnedAddresses: [...recoveryData.pinnedAddresses, ...uniqueNewAddresses]
                    });
                    setScanState('uploaded');
                }
            };
            reader.readAsText(file);
            e.target.value = ''; // Reset file input
        }
    };

    return (
        <div className="h-full flex flex-col">
            <div>
                <h2 className="text-2xl font-bold text-white">System Recovery Scanner</h2>
                <p className="text-slate-400 mt-1">
                    A guided process to find wallet files on your computer and import them for analysis.
                </p>
            </div>

            <div className="mt-6 flex-grow p-6 bg-slate-800/50 border border-slate-700/50 rounded-lg flex flex-col justify-center items-center text-center">
                
                {/* Step 1: Scan */}
                <div className={`w-full max-w-lg transition-opacity duration-500 ${scanState !== 'idle' ? 'opacity-50' : 'opacity-100'}`}>
                    <div className="flex items-center gap-4">
                        <div className={`w-10 h-10 flex items-center justify-center rounded-full text-lg font-bold ${scanState === 'idle' ? 'bg-blue-600 text-white' : 'bg-slate-700 text-slate-400'}`}>1</div>
                        <h3 className="text-xl font-bold text-left text-white">Download & Run Scanner</h3>
                    </div>
                     <p className="text-slate-400 text-left ml-14 mt-1">Download a safe script. Run it on your computer to find wallet files. It will create a `wallet_scan_results.txt` file on your desktop.</p>
                    {scanState === 'idle' && (
                        <div className="ml-14 mt-4 flex flex-col sm:flex-row gap-4">
                            <button
                                onClick={handleDownloadWindows}
                                className="flex items-center justify-center gap-3 px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-md transition-colors w-full"
                            >
                                <Laptop size={20} />
                                Download for Windows
                            </button>
                            <button
                                onClick={handleDownloadMacLinux}
                                className="flex items-center justify-center gap-3 px-6 py-3 bg-slate-600 hover:bg-slate-500 text-white font-semibold rounded-md transition-colors w-full"
                            >
                                <Terminal size={20} />
                                Download for macOS/Linux
                            </button>
                        </div>
                    )}
                </div>

                <div className="w-4/5 h-px bg-slate-700 my-8" />

                {/* Step 2: Upload */}
                 <div className={`w-full max-w-lg transition-opacity duration-500 ${scanState === 'idle' ? 'opacity-50' : 'opacity-100'}`}>
                    <div className="flex items-center gap-4">
                        <div className={`w-10 h-10 flex items-center justify-center rounded-full text-lg font-bold ${scanState !== 'idle' ? 'bg-blue-600 text-white' : 'bg-slate-700 text-slate-400'}`}>2</div>
                        <h3 className="text-xl font-bold text-left text-white">Upload Scan Results</h3>
                    </div>
                     <p className="text-slate-400 text-left ml-14 mt-1">Once the scan is complete, upload the generated `wallet_scan_results.txt` file to automatically add the found paths to your Recovery Hub.</p>
                    {scanState !== 'idle' && scanState !== 'uploaded' && (
                         <div className="ml-14 mt-4">
                            <input
                                type="file"
                                ref={scanResultsInputRef}
                                onChange={handleScanResultsUpload}
                                className="hidden"
                                accept=".txt"
                            />
                            <button
                                onClick={() => scanResultsInputRef.current?.click()}
                                className="flex items-center justify-center gap-3 px-6 py-3 bg-green-600 hover:bg-green-500 text-white font-semibold rounded-md transition-colors w-full"
                            >
                                <UploadCloud size={20} />
                                Upload wallet_scan_results.txt
                            </button>
                        </div>
                    )}
                    {scanState === 'uploaded' && (
                        <div className="ml-14 mt-4 p-4 bg-green-900/50 border border-green-700 rounded-lg text-left">
                            <div className="flex items-center gap-3">
                                <CheckCircle size={24} className="text-green-400" />
                                <div>
                                    <h4 className="font-bold text-white">Upload Complete!</h4>
                                    <p className="text-sm text-green-300">Found paths have been added to your hub.</p>
                                    <button onClick={() => onNavigate(RecoveryMode.HUB)} className="text-sm font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-1 mt-2">
                                        Go to Recovery Hub <ArrowRight size={14} />
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default SystemScanner;