/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, MessageSender } from '../types';
import { getRecoveryGuidance } from '../services/geminiService';
import ChatMessageItem from './ChatMessage';
import { Send } from 'lucide-react';

const FindWalletGuide: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'initial',
      sender: MessageSender.MODEL,
      text: "I can help you find old wallet files by generating a custom search script for your computer. To do this, I need to know your operating system.\n\nFor example, tell me:\n*   'I was using a **Windows 10** laptop.'\n*   'It was on an old **Macbook Pro**.'\n*   'I used an old PC with **Ubuntu Linux**.'",
    }
  ]);
  const [userQuery, setUserQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  const handleSendMessage = async () => {
    if (!userQuery.trim() || isLoading) return;

    const newUserMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      text: userQuery,
      sender: MessageSender.USER,
    };

    const updatedMessages = [...messages, newUserMessage];
    setMessages(updatedMessages);
    setUserQuery('');
    setIsLoading(true);

    try {
      const responseText = await getRecoveryGuidance(updatedMessages);
      const newModelMessage: ChatMessage = {
        id: `model-${Date.now()}`,
        text: responseText,
        sender: MessageSender.MODEL,
      };
      setMessages(prev => [...prev, newModelMessage]);
    } catch (e: any) {
      const errorMessage = e.message || 'An unknown error occurred.';
      const newErrorMessage: ChatMessage = {
        id: `error-${Date.now()}`,
        text: `Error: ${errorMessage}`,
        sender: MessageSender.MODEL,
      };
      setMessages(prev => [...prev, newErrorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full">
      <h2 className="text-2xl font-bold text-white mb-4 shrink-0">Find My Wallet Guide</h2>
      
      <div className="flex-grow overflow-y-auto pr-2 chat-container -mr-2 min-h-0">
          {messages.map((msg) => (
          <ChatMessageItem key={msg.id} message={msg} />
          ))}
          {isLoading && (
              <ChatMessageItem message={{ id: 'loading', sender: MessageSender.MODEL, text: '...', isLoading: true }} />
          )}
          <div ref={messagesEndRef} />
      </div>
  
      <div className="shrink-0 pt-4 mt-4 border-t border-blue-900/50">
          <div className="flex items-center gap-3">
          <textarea
              value={userQuery}
              onChange={(e) => setUserQuery(e.target.value)}
              placeholder="e.g., I was using Windows 7..."
              className="flex-grow h-10 min-h-[40px] py-2 px-3 border border-slate-700 bg-slate-800 text-slate-200 placeholder-slate-500 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none text-sm transition"
              rows={1}
              disabled={isLoading}
              onKeyPress={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
              }
              }}
          />
          <button
              onClick={handleSendMessage}
              disabled={isLoading || !userQuery.trim()}
              className="h-10 w-10 p-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-colors disabled:bg-slate-700 disabled:text-slate-400 flex items-center justify-center flex-shrink-0"
              aria-label="Send message"
          >
              <Send size={20} />
          </button>
          </div>
      </div>
    </div>
  );
};

export default FindWalletGuide;