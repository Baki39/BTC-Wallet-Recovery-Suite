/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect } from 'react';
import * as bip39 from 'bip39';
import { getAdvancedSeedAnalysis } from '../services/geminiService';
import { AlertCircle, CheckCircle, Brain, Loader2, Save, Check, Wand2, Info } from 'lucide-react';
import { SavedSeedPhrase, SeedForensics } from '../types';

const WORD_COUNT = 12;

interface SeedPhraseRecoveryProps {
    initialPhrase?: SavedSeedPhrase;
    onSaveToHub: (phrase: SavedSeedPhrase) => void;
}

const SeedPhraseRecovery: React.FC<SeedPhraseRecoveryProps> = ({ initialPhrase, onSaveToHub }) => {
    const [words, setWords] = useState<string[]>(Array(WORD_COUNT).fill(''));
    const [phraseId, setPhraseId] = useState<string>(`seed-${Date.now()}`);
    const [forensics, setForensics] = useState<SeedForensics | null>(null);
    const [hints, setHints] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [validationStatus, setValidationStatus] = useState<'idle' | 'valid' | 'invalid'>('idle');
    const [isSaved, setIsSaved] = useState(false);

    useEffect(() => {
        if (initialPhrase) {
            const newWords = Array(WORD_COUNT).fill('');
            initialPhrase.words.forEach((word, index) => {
                if (index < WORD_COUNT) {
                    newWords[index] = word;
                }
            });
            setWords(newWords);
            setPhraseId(initialPhrase.id);
        }
    }, [initialPhrase]);

    const handleWordChange = (index: number, value: string) => {
        const newWords = [...words];
        newWords[index] = value.trim().toLowerCase();
        setWords(newWords);
        setValidationStatus('idle');
        setForensics(null);
    };
    
    const handleRunForensics = async () => {
        setIsLoading(true);
        setForensics(null);
        setValidationStatus('idle');

        try {
            const responseText = await getAdvancedSeedAnalysis(words, hints);
            const parsed = JSON.parse(responseText);
            setForensics(parsed);
        } catch (e: any) {
            console.error(e);
            setForensics({ correctedPhrase: 'Error fetching analysis.', wordSuggestions: [], derivationPathInfo: '' });
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleValidate = () => {
        const phrase = words.join(' ');
        if (words.some(w => w === '')) {
            setValidationStatus('invalid');
            return;
        }
        setValidationStatus(bip39.validateMnemonic(phrase) ? 'valid' : 'invalid');
    };

    const handleSave = () => {
        onSaveToHub({ id: phraseId, words });
        setIsSaved(true);
        setTimeout(() => setIsSaved(false), 2000);
    };

    const knownWordsCount = words.filter(w => w.length > 0).length;
    
    return (
        <div className="space-y-6">
            <div className="flex justify-between items-start">
                <div>
                    <h2 className="text-2xl font-bold text-white">Seed Phrase Guesser</h2>
                    <p className="text-slate-400 mt-1">
                        Enter known words and use advanced AI forensics to help recover your full phrase.
                    </p>
                </div>
                <button
                    onClick={handleSave}
                    disabled={knownWordsCount === 0 || isSaved}
                    className={`flex items-center gap-2 px-4 py-2 font-semibold rounded-md transition-colors disabled:cursor-not-allowed flex-shrink-0 ${
                        isSaved
                        ? 'bg-green-600/50 text-green-300'
                        : 'bg-blue-600/50 hover:bg-blue-600 text-blue-300 hover:text-white disabled:bg-slate-700 disabled:text-slate-400'
                    }`}
                >
                    {isSaved ? <Check size={16} /> : <Save size={16} />}
                    {isSaved ? 'Saved!' : 'Save to Hub'}
                </button>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {words.map((word, index) => (
                    <div key={index} className="relative flex items-center">
                        <span className="absolute -left-5 text-sm text-slate-500">{index + 1}.</span>
                        <input
                            type="text"
                            value={word}
                            onChange={(e) => handleWordChange(index, e.target.value)}
                            className="w-full py-2 px-3 border border-slate-700 bg-slate-800 text-slate-200 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                            placeholder="..."
                        />
                    </div>
                ))}
            </div>

             <div className="flex justify-end">
                 <button
                    onClick={handleValidate}
                    disabled={words.some(w => w === '')}
                    className="flex items-center justify-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-500 text-white font-semibold rounded-md transition-colors disabled:bg-slate-700 disabled:text-slate-400 disabled:cursor-not-allowed"
                >
                    <CheckCircle size={18}/>
                    Validate Phrase
                </button>
            </div>
            
            {validationStatus === 'valid' && <div className="flex items-center gap-2 text-green-400 p-4 bg-green-900/50 rounded-lg"><CheckCircle size={20}/> Valid BIP39 Phrase! Remember to check different derivation paths.</div>}
            {validationStatus === 'invalid' && <div className="flex items-center gap-2 text-red-400 p-4 bg-red-900/50 rounded-lg"><AlertCircle size={20}/> Invalid or incomplete phrase. Use the forensics tool below for help.</div>}

            {/* Forensics Section */}
            <div className="p-4 bg-slate-800/50 border border-slate-700/50 rounded-lg space-y-4">
                <h3 className="text-lg font-bold text-white flex items-center gap-2"><Wand2 className="text-purple-400"/> Advanced Seed Phrase Forensics</h3>
                <div>
                     <label htmlFor="hints" className="block text-sm font-medium text-slate-300 mb-1">Hints for Missing Words (Optional)</label>
                     <input
                        id="hints"
                        type="text"
                        value={hints}
                        onChange={(e) => setHints(e.target.value)}
                        className="w-full py-2 px-3 border border-slate-700 bg-slate-900 text-slate-200 rounded-md focus:ring-2 focus:ring-blue-500"
                        placeholder="e.g., words related to nature, space, or animals"
                    />
                </div>
                <button
                    onClick={handleRunForensics}
                    disabled={isLoading || knownWordsCount === 0}
                    className="flex items-center justify-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-semibold rounded-md transition-colors disabled:bg-slate-700 disabled:text-slate-400 disabled:cursor-not-allowed"
                >
                    {isLoading ? <Loader2 size={20} className="animate-spin" /> : <Brain size={20} />}
                    Run AI Analysis
                </button>

                 {forensics && !isLoading && (
                    <div className="space-y-4 pt-4 border-t border-slate-700">
                        {forensics.correctedPhrase && (
                             <div>
                                <h4 className="font-semibold text-slate-200">Typo Correction</h4>
                                <p className="text-sm text-slate-400">AI suggests this corrected phrase: <code className="bg-slate-700 p-1 rounded text-slate-200 font-mono">{forensics.correctedPhrase}</code></p>
                             </div>
                        )}
                        {forensics.wordSuggestions && forensics.wordSuggestions.length > 0 && (
                            <div>
                                <h4 className="font-semibold text-slate-200">Word Suggestions (based on hints)</h4>
                                 <div className="flex flex-wrap gap-2 mt-2">
                                    {forensics.wordSuggestions.map((s, i) => (
                                        <span key={i} className="px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full text-sm font-mono cursor-pointer hover:bg-blue-500/40 transition" title="Click to copy" onClick={() => navigator.clipboard.writeText(s)}>{s}</span>
                                    ))}
                                </div>
                            </div>
                        )}
                        {forensics.derivationPathInfo && (
                            <div className="p-3 bg-slate-900/50 rounded-lg flex items-start gap-3">
                                <Info size={18} className="text-blue-400 shrink-0 mt-1" />
                                <div>
                                    <h4 className="font-semibold text-slate-200">Important: Derivation Paths</h4>
                                    <p className="text-sm text-slate-400">{forensics.derivationPathInfo}</p>
                                </div>
                            </div>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};

export default SeedPhraseRecovery;