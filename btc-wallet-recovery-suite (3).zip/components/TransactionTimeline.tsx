/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React from 'react';
import { TimelineEvent } from '../types';
import { Calendar, ChevronsRight, ArrowDown, ArrowUp, Milestone } from 'lucide-react';

interface TransactionTimelineProps {
  events: TimelineEvent[];
}

const getIconForType = (type: string) => {
    switch(type) {
        case 'First Activity':
            return <ChevronsRight size={16} className="text-green-400"/>;
        case 'Last Activity':
            return <ChevronsRight size={16} className="text-red-400" style={{transform: 'rotate(180deg)'}}/>;
        case 'Major Deposit':
            return <ArrowDown size={16} className="text-blue-400"/>;
        case 'Major Withdrawal':
            return <ArrowUp size={16} className="text-orange-400"/>;
        default:
            return <Milestone size={16} className="text-slate-400"/>;
    }
};

const TransactionTimeline: React.FC<TransactionTimelineProps> = ({ events }) => {
    if (!events || events.length === 0) {
        return <div className="text-slate-500 text-sm">No timeline events available for this address.</div>;
    }

    return (
        <div className="w-full bg-slate-800/50 border border-slate-700/50 rounded-lg p-6">
            <div className="relative flex items-center h-24">
                {/* Timeline Line */}
                <div className="absolute top-1/2 left-0 w-full h-0.5 bg-slate-600 -translate-y-1/2" />

                {/* Events */}
                <div className="relative flex justify-between w-full">
                    {events.map((event, index) => (
                        <div key={index} className="relative flex flex-col items-center timeline-event">
                            {/* Dot */}
                            <div className="w-4 h-4 bg-slate-700 border-2 border-blue-500 rounded-full z-10" />
                            
                            {/* Tooltip */}
                            <div className="timeline-tooltip absolute bottom-full mb-3 w-48 p-2 bg-slate-900 border border-slate-700 rounded-md shadow-lg z-20 text-center">
                                <div className="flex items-center justify-center gap-1.5 mb-1 text-xs text-slate-400">
                                    <Calendar size={12}/> {event.date}
                                </div>
                                <div className="flex items-center justify-center gap-1.5 text-xs font-semibold text-slate-200">
                                   {getIconForType(event.type)} {event.type}
                                </div>
                                <p className="text-[11px] text-slate-400 mt-1">{event.description}</p>
                                <div className="absolute left-1/2 -bottom-1 w-2 h-2 bg-slate-900 transform rotate-45 -translate-x-1/2" />
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default TransactionTimeline;
