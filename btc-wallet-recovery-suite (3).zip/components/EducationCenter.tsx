/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, MessageSender } from '../types';
import { getScamSimulationResponse } from '../services/geminiService';
import ChatMessageItem from './ChatMessage';
import { Send, ShieldCheck, MessageSquareWarning } from 'lucide-react';

const EducationCenter: React.FC = () => {
    const [activeTab, setActiveTab] = useState<'simulator' | 'checklist'>('simulator');
  
    return (
      <div className="space-y-6">
        <h2 className="text-2xl font-bold text-white">Education Center</h2>
        <div className="flex border-b border-blue-900/50">
          <TabButton
            icon={<MessageSquareWarning />}
            label="Scam Simulator"
            isActive={activeTab === 'simulator'}
            onClick={() => setActiveTab('simulator')}
          />
          <TabButton
            icon={<ShieldCheck />}
            label="Security Checklist"
            isActive={activeTab === 'checklist'}
            onClick={() => setActiveTab('checklist')}
          />
        </div>
        <div>
          {activeTab === 'simulator' ? <ScamSimulator /> : <SecurityChecklist />}
        </div>
      </div>
    );
};

interface TabButtonProps {
    icon: React.ReactNode;
    label: string;
    isActive: boolean;
    onClick: () => void;
}
const TabButton: React.FC<TabButtonProps> = ({ icon, label, isActive, onClick }) => (
    <button
      onClick={onClick}
      className={`flex items-center gap-2 px-4 py-2 text-sm font-medium border-b-2 transition ${
        isActive
          ? 'border-blue-500 text-blue-400'
          : 'border-transparent text-slate-400 hover:text-white'
      }`}
    >
      {icon}
      {label}
    </button>
);


const ScamSimulator: React.FC = () => {
    const [messages, setMessages] = useState<ChatMessage[]>([
        {
          id: 'initial',
          sender: MessageSender.MODEL,
          text: "Welcome to the Scam Simulation. I am going to act like a scammer to help you practice spotting the signs. Your goal is to protect your assets. Let's begin...\n\nHello! I'm a support agent from 'Global Crypto Wallets'. We've noticed a security alert on your account. To protect your funds, we need to verify your wallet immediately.",
        }
      ]);
      const [userQuery, setUserQuery] = useState('');
      const [isLoading, setIsLoading] = useState(false);
      const messagesEndRef = useRef<HTMLDivElement>(null);
    
      const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
      };
    
      useEffect(scrollToBottom, [messages]);
    
      const handleSendMessage = async () => {
        if (!userQuery.trim() || isLoading) return;
    
        const newUserMessage: ChatMessage = { id: `user-${Date.now()}`, text: userQuery, sender: MessageSender.USER };
        const updatedMessages = [...messages, newUserMessage];
        setMessages(updatedMessages);
        setUserQuery('');
        setIsLoading(true);
    
        try {
          const responseText = await getScamSimulationResponse(updatedMessages);
          const newModelMessage: ChatMessage = { id: `model-${Date.now()}`, text: responseText, sender: MessageSender.MODEL };
          setMessages(prev => [...prev, newModelMessage]);
        } catch (e: any) {
          const errorMessage = e.message || 'An unknown error occurred.';
          setMessages(prev => [...prev, { id: `error-${Date.now()}`, text: `Error: ${errorMessage}`, sender: MessageSender.MODEL }]);
        } finally {
          setIsLoading(false);
        }
      };

    return (
        <div className="flex flex-col h-[60vh] bg-slate-800/50 border border-slate-700/50 rounded-lg p-4">
            <p className="text-sm text-slate-400 mb-4 p-2 bg-yellow-900/30 border border-yellow-700 rounded-lg">
                <strong>Objective:</strong> Interact with the AI bot. It will try to trick you into revealing sensitive information. See if you can spot the scam tactics.
            </p>
            <div className="flex-grow overflow-y-auto pr-2 chat-container -mr-2">
                {messages.map((msg) => <ChatMessageItem key={msg.id} message={msg} />)}
                {isLoading && <ChatMessageItem message={{ id: 'loading', sender: MessageSender.MODEL, text: '...', isLoading: true }} />}
                <div ref={messagesEndRef} />
            </div>
            <div className="pt-4 mt-2 border-t border-blue-900/50">
                <div className="flex items-center gap-3">
                    <textarea
                        value={userQuery}
                        onChange={(e) => setUserQuery(e.target.value)}
                        placeholder="Respond to the 'support agent'..."
                        className="flex-grow h-10 min-h-[40px] py-2 px-3 border border-slate-700 bg-slate-900 text-slate-200 placeholder-slate-500 rounded-lg focus:ring-2 focus:ring-blue-500 resize-none text-sm"
                        rows={1}
                        disabled={isLoading}
                        onKeyPress={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage(); }}}
                    />
                    <button onClick={handleSendMessage} disabled={isLoading || !userQuery.trim()} className="h-10 w-10 p-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-colors disabled:bg-slate-700 disabled:text-slate-400 flex items-center justify-center flex-shrink-0" aria-label="Send message">
                        <Send size={20} />
                    </button>
                </div>
            </div>
        </div>
    );
};


const SecurityChecklist: React.FC = () => (
    <div className="p-6 bg-slate-800/50 border border-slate-700/50 rounded-lg space-y-4">
      <div className="prose prose-sm max-w-none">
        <h3 className="text-xl text-white">Essential Crypto Security Practices</h3>
        <p className="text-slate-400">Follow these rules to keep your crypto safe. This is especially important after recovering an old wallet.</p>
        <ul>
          <li><strong>NEVER Share Your Seed Phrase:</strong> Your 12 or 24-word seed phrase is the master key to all your funds. Anyone with it can steal your assets. No legitimate support, admin, or company will ever ask for it.</li>
          <li><strong>Migrate Recovered Funds:</strong> If you recover an old wallet, assume the old device or software might be compromised. The safest action is to immediately create a brand new, modern wallet and transfer all funds to it.</li>
          <li><strong>Use a Hardware Wallet:</strong> For significant amounts, invest in a hardware wallet (like Ledger or Trezor). It keeps your private keys offline, providing the best protection against online threats.</li>
          <li><strong>Beware of Phishing:</strong> Scammers create fake websites that look identical to real ones. Always double-check the URL. Bookmark official sites and use those bookmarks instead of clicking links from emails or social media.</li>
          <li><strong>Store Your Seed Phrase Physically:</strong> Write your seed phrase on paper or stamp it into metal. Store it in a secure, private location (like a safe). Do not store it digitally (e.g., in a text file, cloud drive, or password manager) as this is vulnerable to hacking.</li>
          <li><strong>Verify Software:</strong> Only download wallet software from official websites. Check for developer signatures and community reviews to ensure it's legitimate.</li>
        </ul>
      </div>
    </div>
);


export default EducationCenter;