/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState } from 'react';
import { marked } from 'marked';
import hljs from 'highlight.js';
import { ChatMessage, MessageSender } from '../types';
import { Bot, User, Clipboard, ClipboardCheck } from 'lucide-react';

// FIX: Cast options to 'any' to bypass type error for 'highlight' property.
marked.setOptions({
  highlight: function(code, lang) {
    const language = hljs.getLanguage(lang) ? lang : 'plaintext';
    return hljs.highlight(code, { language }).value;
  },
  langPrefix: 'hljs language-',
} as any);

interface MessageItemProps {
  message: ChatMessage;
}

const SenderAvatar: React.FC<{ sender: MessageSender }> = ({ sender }) => {
  if (sender === MessageSender.USER) {
    return (
        <div className="w-9 h-9 rounded-full bg-slate-700 text-slate-300 flex items-center justify-center flex-shrink-0">
            <User size={18} />
        </div>
    );
  }
  
  return (
    <div className="w-9 h-9 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center flex-shrink-0">
        <Bot size={18} />
    </div>
  );
};

const CodeBlock: React.FC<{ code: string }> = ({ code }) => {
    const [isCopied, setIsCopied] = useState(false);
    
    const handleCopy = () => {
        navigator.clipboard.writeText(code);
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2000);
    };

    const rawHtml = marked.parse(`\`\`\`\n${code}\`\`\``) as string;

    return (
        <div className="code-block-wrapper my-2">
            <div className="prose" dangerouslySetInnerHTML={{ __html: rawHtml }}/>
            <button onClick={handleCopy} className="copy-button">
                {isCopied ? <ClipboardCheck size={14} /> : <Clipboard size={14} />}
                <span className="ml-1">{isCopied ? 'Copied!' : 'Copy'}</span>
            </button>
        </div>
    );
};

const ChatMessageItem: React.FC<MessageItemProps> = ({ message }) => {
  const isUser = message.sender === MessageSender.USER;

  const renderMessageContent = () => {
    if (message.isLoading) {
        return (
            <div className="flex items-center space-x-1.5">
              <div className="w-1.5 h-1.5 bg-current rounded-full animate-bounce [animation-delay:-0.3s]"></div>
              <div className="w-1.5 h-1.5 bg-current rounded-full animate-bounce [animation-delay:-0.15s]"></div>
              <div className="w-1.5 h-1.5 bg-current rounded-full animate-bounce"></div>
            </div>
        )
    }

    // Split message by code blocks to render them with a copy button
    const parts = message.text.split(/(```(?:[a-zA-Z]+\n)?[\s\S]*?```)/g);

    return (
      <div>
        {parts.map((part, index) => {
          const codeMatch = part.match(/```(?:[a-zA-Z]+\n)?([\s\S]*?)```/);
          if (codeMatch) {
            return <CodeBlock key={index} code={codeMatch[1]} />;
          } else if (part.trim()) {
            return (
              <div
                key={index}
                className="prose prose-sm max-w-none"
                dangerouslySetInnerHTML={{ __html: marked.parse(part) as string }}
              />
            );
          }
          return null;
        })}
      </div>
    );
  };

  return (
    <div className={`flex items-start gap-3 my-4 ${isUser ? 'justify-end' : 'justify-start'}`}>
      {!isUser && <SenderAvatar sender={message.sender} />}
      
      <div className={`p-4 rounded-lg max-w-[90%] md:max-w-[80%] shadow-lg ${isUser ? 'bg-blue-600/50 text-white rounded-br-none' : 'bg-slate-800/70 text-slate-300 rounded-bl-none border border-slate-700'}`}>
          {renderMessageContent()}
      </div>

      {isUser && <SenderAvatar sender={message.sender} />}
    </div>
  );
};

export default ChatMessageItem;