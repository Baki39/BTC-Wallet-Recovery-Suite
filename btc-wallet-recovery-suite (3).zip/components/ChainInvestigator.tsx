/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect } from 'react';
import { getBlockchainAnalysis } from '../services/geminiService';
import { marked } from 'marked';
import { Search, Loader2, AlertTriangle, Lightbulb, CheckSquare, Pin, Check } from 'lucide-react';
import { AnalysisResult, RecoveryMode, PinnedAddress } from '../types';
import TransactionTimeline from './TransactionTimeline';

interface ChainInvestigatorProps {
    initialAddress?: string;
    onNavigate: (mode: RecoveryMode) => void;
    onPinToHub: (address: PinnedAddress) => void;
}

const ChainInvestigator: React.FC<ChainInvestigatorProps> = ({ initialAddress, onNavigate, onPinToHub }) => {
    const [address, setAddress] = useState('');
    const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isPinned, setIsPinned] = useState(false);

    useEffect(() => {
        if (initialAddress) {
            setAddress(initialAddress);
            // Optionally auto-run analysis if an address is passed
            // handleAnalyze(initialAddress);
        }
    }, [initialAddress]);


    const handleAnalyze = async () => {
        if (!address.trim() || isLoading) return;
        setIsLoading(true);
        setError(null);
        setAnalysis(null);
        try {
            if (!/^(1|3|bc1)[a-zA-HJ-NP-Z0-9]{25,39}$/.test(address)) {
                throw new Error("Invalid Bitcoin address format.");
            }
            const resultText = await getBlockchainAnalysis(address);
            setAnalysis(JSON.parse(resultText));
        } catch (e: any) {
            setError(e.message || 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    };

    const handlePin = () => {
        if (!address.trim()) return;
        onPinToHub({ id: `addr-${address}`, address });
        setIsPinned(true);
        setTimeout(() => setIsPinned(false), 2000);
    };

    const renderResult = () => {
        if (isLoading) {
            return (
                <div className="flex flex-col items-center justify-center p-8 text-center bg-slate-800/50 rounded-lg">
                    <Loader2 size={32} className="animate-spin text-blue-400 mb-4" />
                    <p className="text-slate-300">AI is investigating the blockchain...</p>
                </div>
            );
        }
        if (error) {
            return (
                <div className="flex items-start gap-3 p-4 bg-red-900/30 border border-red-700 rounded-lg">
                    <AlertTriangle size={24} className="text-red-400 shrink-0 mt-1" />
                    <div>
                        <h3 className="font-bold text-red-300">Analysis Failed</h3>
                        <p className="text-sm text-red-300/80">{error}</p>
                    </div>
                </div>
            );
        }
        if (analysis) {
            const origin = analysis.walletOriginGuess;
            const targetMode = origin === 'Bitcoin Core (wallet.dat)' ? RecoveryMode.DECRYPT : 
                               (origin === 'Coinbase' || origin === 'Blockchain.info (Web Wallet)') ? RecoveryMode.GUIDE : null;
            const isClickable = !!targetMode;

            return (
                <div className="space-y-6 fade-in">
                    <div className="p-6 bg-slate-800/50 border border-slate-700/50 rounded-lg">
                        <div className="flex items-start gap-4">
                            <Lightbulb size={24} className="text-yellow-400 shrink-0 mt-1"/>
                            <div>
                                <h3 className="text-lg font-bold text-white mb-2">AI Analysis Summary</h3>
                                <div className="prose prose-sm max-w-none prose-invert mb-4" dangerouslySetInnerHTML={{ __html: marked.parse(analysis.summary) as string }} />
                                <div className="mt-4 p-3 bg-blue-900/30 border border-blue-700/50 rounded-lg">
                                    <p className="text-xs text-blue-300/80 font-semibold uppercase tracking-wider">Probable Wallet Origin</p>
                                    {isClickable && targetMode ? (
                                        <button onClick={() => onNavigate(targetMode)} className="text-xl font-bold text-white text-left w-full hover:text-blue-400 hover:underline">
                                            {origin}
                                        </button>
                                    ) : (
                                        <p className="text-xl font-bold text-white">{origin}</p>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>
                        <h3 className="text-lg font-semibold text-white mb-3">Transaction Timeline</h3>
                        <TransactionTimeline events={analysis.timelineEvents} />
                    </div>
                    <div>
                         <h3 className="text-lg font-semibold text-white mb-3">Personalized Recovery Path</h3>
                         <div className="space-y-3">
                            {analysis.recoverySteps.map((step, index) => (
                                <div key={index} className="flex items-start gap-3 p-4 bg-slate-800/50 border border-slate-700/50 rounded-lg">
                                    <CheckSquare size={20} className="text-green-400 shrink-0 mt-1"/>
                                    <div>
                                        <h4 className="font-bold text-slate-100">{step.title}</h4>
                                        <p className="text-sm text-slate-400">{step.description}</p>
                                    </div>
                                </div>
                            ))}
                         </div>
                    </div>
                </div>
            );
        }
        return null;
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-start">
                <div>
                    <h2 className="text-2xl font-bold text-white">AI Chain Investigator</h2>
                    <p className="text-slate-400 mt-1">Enter a Bitcoin address for forensic analysis and clues.</p>
                </div>
                <button
                    onClick={handlePin}
                    disabled={!address.trim() || isPinned}
                    className={`flex items-center gap-2 px-4 py-2 font-semibold rounded-md transition-colors disabled:cursor-not-allowed flex-shrink-0 ${
                        isPinned
                        ? 'bg-green-600/50 text-green-300'
                        : 'bg-blue-600/50 hover:bg-blue-600 text-blue-300 hover:text-white disabled:bg-slate-700 disabled:text-slate-400'
                    }`}
                >
                    {isPinned ? <Check size={16} /> : <Pin size={16} />}
                    {isPinned ? 'Pinned!' : 'Pin to Hub'}
                </button>
            </div>
            
            <div className="flex items-center gap-3">
                <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Enter Bitcoin address..."
                    className="flex-grow h-10 py-2 px-3 border border-slate-700 bg-slate-800 text-slate-200 placeholder-slate-500 rounded-lg focus:ring-2 focus:ring-blue-500"
                    disabled={isLoading}
                    onKeyPress={(e) => { if (e.key === 'Enter') { e.preventDefault(); handleAnalyze(); }}}
                />
                <button
                    onClick={handleAnalyze}
                    disabled={isLoading || !address.trim()}
                    className="h-10 w-32 px-4 bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-colors disabled:bg-slate-700 disabled:text-slate-400 flex items-center justify-center"
                >
                    {isLoading ? <Loader2 size={20} className="animate-spin" /> : <><Search size={20} className="mr-2"/> Analyze</>}
                </button>
            </div>
            
            <div className="mt-6">
                {renderResult()}
            </div>
        </div>
    );
};

export default ChainInvestigator;