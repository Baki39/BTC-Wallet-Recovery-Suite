/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useRef } from 'react';
import { RecoveryData, RecoveryMode, LoadedFile, PinnedAddress } from '../types';
import { UploadCloud, File, Trash2, Edit, Search, ShieldCheck, BrainCircuit, Key } from 'lucide-react';

interface RecoveryHubProps {
    recoveryData: RecoveryData;
    onUpdateData: (data: RecoveryData) => void;
    onNavigate: (mode: RecoveryMode, itemId?: string) => void;
}

const RecoveryHub: React.FC<RecoveryHubProps> = ({ recoveryData, onUpdateData, onNavigate }) => {
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            const file = e.target.files[0];
            const loadedFile: LoadedFile = { name: file.name, size: file.size };
            onUpdateData({ ...recoveryData, file: loadedFile });
        }
    };

    const handleNotesChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        onUpdateData({ ...recoveryData, notes: e.target.value });
    };

    const removeFile = () => onUpdateData({ ...recoveryData, file: null });
    const removeSeedPhrase = (id: string) => onUpdateData({ ...recoveryData, seedPhrases: recoveryData.seedPhrases.filter(p => p.id !== id) });
    const removePinnedAddress = (id: string) => onUpdateData({ ...recoveryData, pinnedAddresses: recoveryData.pinnedAddresses.filter(p => p.id !== id) });

    const formatBytes = (bytes: number, decimals = 2) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    };

    return (
        <div className="space-y-8">
            <div>
                <h2 className="text-3xl font-bold text-white">Recovery Hub</h2>
                <p className="text-slate-400 mt-1">Your central dashboard for managing recovery artifacts. All data is saved locally in your browser.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Left Column Group */}
                <div className="flex flex-col gap-8">
                    {/* Wallet File */}
                    <HubSection title="Wallet File" icon={<ShieldCheck className="text-green-400" />}>
                        {recoveryData.file ? (
                            <div className="p-3 bg-slate-800/70 rounded-lg flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    <File size={20} className="text-slate-400"/>
                                    <div>
                                        <p className="font-medium text-slate-200">{recoveryData.file.name}</p>
                                        <p className="text-xs text-slate-500">{formatBytes(recoveryData.file.size)}</p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-2">
                                    <button onClick={() => onNavigate(RecoveryMode.DECRYPT)} className="p-2 text-slate-300 hover:text-white hover:bg-blue-600 rounded-md transition" title="Go to Decryptor"><Key size={16}/></button>
                                    <button onClick={removeFile} className="p-2 text-slate-400 hover:text-red-400 hover:bg-red-500/20 rounded-md transition" title="Remove File"><Trash2 size={16}/></button>
                                </div>
                            </div>
                        ) : (
                            <div className="flex flex-col items-center justify-center text-center p-6 bg-slate-800/50 border-2 border-dashed border-slate-700 rounded-xl">
                                <UploadCloud size={32} className="text-slate-500 mb-2" />
                                <p className="text-slate-400 text-sm mb-3">Load a `wallet.dat` file to use the decryptor.</p>
                                <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept=".dat" />
                                <button onClick={() => fileInputRef.current?.click()} className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-sm font-semibold rounded-md transition-colors">
                                    Select File
                                </button>
                            </div>
                        )}
                    </HubSection>

                    {/* Seed Phrases */}
                    <HubSection title="Saved Seed Phrases" icon={<BrainCircuit className="text-purple-400" />}>
                        <div className="space-y-2">
                            {recoveryData.seedPhrases.length > 0 ? recoveryData.seedPhrases.map(phrase => (
                                <div key={phrase.id} className="p-3 bg-slate-800/70 rounded-lg flex items-center justify-between gap-4">
                                    <p className="text-sm text-slate-300 font-mono truncate flex-1 min-w-0" title={phrase.words.join(' ')}>
                                        {phrase.words.map(w => w || '...').join(' ')}
                                    </p>
                                    <div className="flex items-center gap-2 flex-shrink-0">
                                        <button onClick={() => onNavigate(RecoveryMode.SEED, phrase.id)} className="p-2 text-slate-300 hover:text-white hover:bg-blue-600 rounded-md transition" title="Edit in Guesser"><Edit size={16}/></button>
                                        <button onClick={() => removeSeedPhrase(phrase.id)} className="p-2 text-slate-400 hover:text-red-400 hover:bg-red-500/20 rounded-md transition" title="Remove Phrase"><Trash2 size={16}/></button>
                                    </div>
                                </div>
                            )) : <p className="text-slate-500 text-sm text-center py-4">No seed phrases saved yet.</p>}
                            <button onClick={() => onNavigate(RecoveryMode.SEED)} className="w-full text-sm py-2 text-blue-400 hover:text-white bg-blue-500/10 hover:bg-blue-500/20 rounded-md transition">
                                + Add New Seed Phrase
                            </button>
                        </div>
                    </HubSection>

                     {/* Pinned Addresses */}
                     <HubSection title="Pinned Addresses" icon={<Search className="text-blue-400" />}>
                        <div className="space-y-2">
                            {recoveryData.pinnedAddresses.length > 0 ? recoveryData.pinnedAddresses.map(addr => (
                                <div key={addr.id} className="p-3 bg-slate-800/70 rounded-lg flex items-center justify-between gap-4">
                                    <p className="text-sm text-slate-300 font-mono truncate flex-1 min-w-0" title={addr.address}>{addr.address}</p>
                                    <div className="flex items-center gap-2 flex-shrink-0">
                                        <button onClick={() => onNavigate(RecoveryMode.INVESTIGATE, addr.id)} className="p-2 text-slate-300 hover:text-white hover:bg-blue-600 rounded-md transition" title="Investigate Address"><Search size={16}/></button>
                                        <button onClick={() => removePinnedAddress(addr.id)} className="p-2 text-slate-400 hover:text-red-400 hover:bg-red-500/20 rounded-md transition" title="Remove Address"><Trash2 size={16}/></button>
                                    </div>
                                </div>
                            )) : <p className="text-slate-500 text-sm text-center py-4">No addresses or paths pinned yet.</p>}
                            <div className="grid grid-cols-1 pt-2">
                                <button onClick={() => onNavigate(RecoveryMode.INVESTIGATE)} className="w-full text-sm py-2 text-blue-400 hover:text-white bg-blue-500/10 hover:bg-blue-500/20 rounded-md transition">
                                    + Investigate New Address
                                </button>
                            </div>
                        </div>
                    </HubSection>
                </div>
                
                {/* Right Column Group */}
                <div className="flex flex-col">
                    <HubSection title="Recovery Notes" icon={<Edit className="text-yellow-400" />}>
                        <textarea
                            value={recoveryData.notes}
                            onChange={handleNotesChange}
                            placeholder="Jot down any clues, memories, or password ideas here..."
                            className="w-full h-full min-h-[300px] lg:min-h-0 p-3 border border-slate-700 bg-slate-800 text-slate-200 placeholder-slate-500 rounded-lg focus:ring-2 focus:ring-blue-500 resize-none text-sm transition"
                        />
                    </HubSection>
                </div>
            </div>
        </div>
    );
};

interface HubSectionProps {
    title: string;
    icon: React.ReactNode;
    children: React.ReactNode;
}
const HubSection: React.FC<HubSectionProps> = ({ title, icon, children }) => (
    <div className="bg-slate-900/30 border border-blue-900/30 rounded-xl p-4 h-full flex flex-col">
        <div className="flex items-center gap-2 mb-3">
            {icon}
            <h3 className="text-lg font-semibold text-slate-200">{title}</h3>
        </div>
        <div className="flex-grow">
            {children}
        </div>
    </div>
);


export default RecoveryHub;