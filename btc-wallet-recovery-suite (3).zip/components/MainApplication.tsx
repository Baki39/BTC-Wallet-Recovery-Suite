/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState, useEffect } from 'react';
import { RecoveryMode, RecoveryData } from '../types';
import FindWalletGuide from './FindWalletGuide';
import SeedPhraseRecovery from './SeedPhraseRecovery';
import WalletDatDecryptor from './WalletDatDecryptor';
import PasswordRecovery from './PasswordRecovery';
import EducationCenter from './EducationCenter';
import ChainInvestigator from './ChainInvestigator';
import RecoveryHub from './RecoveryHub';
import SystemScanner from './SystemScanner';
import { KeyRound, BrainCircuit, Search, ShieldCheck, BookOpen, Bot, Webhook, LayoutDashboard, Download, LogOut } from 'lucide-react';

const STORAGE_KEY = 'btc-recovery-hub-data';

const getDefaultRecoveryData = (): RecoveryData => ({
    file: null,
    seedPhrases: [],
    pinnedAddresses: [],
    notes: '',
});

interface MainApplicationProps {
    onLogout: () => void;
}

const MainApplication: React.FC<MainApplicationProps> = ({ onLogout }) => {
  const [mode, setMode] = useState<RecoveryMode>(RecoveryMode.HUB);
  const [recoveryData, setRecoveryData] = useState<RecoveryData>(getDefaultRecoveryData());
  const [activeItemId, setActiveItemId] = useState<string | null>(null);

  useEffect(() => {
    try {
      const storedData = localStorage.getItem(STORAGE_KEY);
      if (storedData) {
        setRecoveryData(JSON.parse(storedData));
      }
    } catch (error) {
      console.error("Failed to load data from localStorage", error);
      setRecoveryData(getDefaultRecoveryData());
    }
  }, []);

  const handleUpdateRecoveryData = (data: RecoveryData) => {
    setRecoveryData(data);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (error) {
      console.error("Failed to save data to localStorage", error);
    }
  };

  const handleSetMode = (newMode: RecoveryMode, itemId: string | null = null) => {
    setActiveItemId(itemId);
    setMode(newMode);
  };

  const renderContent = () => {
    switch (mode) {
      case RecoveryMode.HUB:
        return <RecoveryHub recoveryData={recoveryData} onUpdateData={handleUpdateRecoveryData} onNavigate={handleSetMode} />;
      case RecoveryMode.PASSWORD:
        return <PasswordRecovery />;
      case RecoveryMode.DECRYPT:
        return <WalletDatDecryptor loadedFile={recoveryData.file} />;
      case RecoveryMode.SEED:
        const initialPhrase = recoveryData.seedPhrases.find(p => p.id === activeItemId) || undefined;
        return <SeedPhraseRecovery 
            initialPhrase={initialPhrase} 
            onSaveToHub={(phrase) => {
                const existing = recoveryData.seedPhrases.find(p => p.id === phrase.id);
                let newPhrases;
                if (existing) {
                    newPhrases = recoveryData.seedPhrases.map(p => p.id === phrase.id ? phrase : p);
                } else {
                    newPhrases = [...recoveryData.seedPhrases, phrase];
                }
                handleUpdateRecoveryData({ ...recoveryData, seedPhrases: newPhrases });
            }}
        />;
      case RecoveryMode.SCANNER:
        return <SystemScanner recoveryData={recoveryData} onUpdateData={handleUpdateRecoveryData} onNavigate={handleSetMode} />;
      case RecoveryMode.GUIDE:
        return <FindWalletGuide />;
      case RecoveryMode.EDUCATION:
        return <EducationCenter />;
      case RecoveryMode.INVESTIGATE:
        const initialAddress = recoveryData.pinnedAddresses.find(p => p.id === activeItemId)?.address || '';
        return <ChainInvestigator 
            initialAddress={initialAddress}
            onNavigate={(targetMode) => handleSetMode(targetMode)}
            onPinToHub={(address) => {
                const existing = recoveryData.pinnedAddresses.find(p => p.id === address.id);
                let newAddresses;
                if (existing) {
                    newAddresses = recoveryData.pinnedAddresses.map(p => p.id === address.id ? address : p);
                } else {
                    newAddresses = [...recoveryData.pinnedAddresses, address];
                }
                handleUpdateRecoveryData({ ...recoveryData, pinnedAddresses: newAddresses });
            }}
        />;
      default:
        return <RecoveryHub recoveryData={recoveryData} onUpdateData={handleUpdateRecoveryData} onNavigate={handleSetMode} />;
    }
  };

  return (
    <div className="h-screen max-h-screen antialiased bg-[#020617] text-[#E2E2E2] flex flex-col font-sans">
       <header className="flex items-center justify-between p-3 border-b border-blue-900/50 shrink-0 bg-slate-900/50">
        <div className="flex items-center gap-3">
            <Bot size={28} className="text-blue-400"/>
            <h1 className="text-xl font-bold text-white tracking-wider">BTC Wallet Recovery Suite</h1>
        </div>
        <button onClick={onLogout} className="flex items-center gap-2 px-3 py-1.5 text-sm font-semibold text-slate-300 hover:text-white bg-slate-700/50 hover:bg-slate-700 rounded-md transition-colors">
            <LogOut size={16} />
            Log Out
        </button>
      </header>
      <div className="flex flex-grow overflow-hidden">
        <aside className="w-64 bg-slate-900/30 p-4 border-r border-blue-900/50 flex flex-col shrink-0">
            <nav className="flex flex-col gap-2">
                <NavButton icon={<LayoutDashboard size={20} />} text="Recovery Hub" mode={RecoveryMode.HUB} activeMode={mode} onClick={handleSetMode} />
                <p className="text-sm text-blue-400/60 font-semibold uppercase tracking-wider mt-4 mb-2">Recovery Tools</p>
                <NavButton icon={<Download size={20} />} text="System Recovery Scanner" mode={RecoveryMode.SCANNER} activeMode={mode} onClick={handleSetMode} />
                <NavButton icon={<ShieldCheck size={20} />} text="Wallet File Decryptor" mode={RecoveryMode.DECRYPT} activeMode={mode} onClick={handleSetMode} />
                <NavButton icon={<KeyRound size={20} />} text="AI Password Brainstorm" mode={RecoveryMode.PASSWORD} activeMode={mode} onClick={handleSetMode} />
                <NavButton icon={<BrainCircuit size={20} />} text="Seed Phrase Guesser" mode={RecoveryMode.SEED} activeMode={mode} onClick={handleSetMode} />
                <NavButton icon={<Search size={20} />} text="Find My Wallet Guide" mode={RecoveryMode.GUIDE} activeMode={mode} onClick={handleSetMode} />
                <NavButton icon={<Webhook size={20} />} text="AI Chain Investigator" mode={RecoveryMode.INVESTIGATE} activeMode={mode} onClick={handleSetMode} />
                <p className="text-sm text-blue-400/60 font-semibold uppercase tracking-wider mt-4 mb-2">Learn</p>
                <NavButton icon={<BookOpen size={20} />} text="Education Center" mode={RecoveryMode.EDUCATION} activeMode={mode} onClick={handleSetMode} />
            </nav>
        </aside>
        <main className="flex-grow overflow-y-auto bg-[#0f172a]">
          <div className="max-w-5xl mx-auto p-4 md:p-8 h-full fade-in" key={mode}>
            {renderContent()}
          </div>
        </main>
      </div>
    </div>
  );
};

interface NavButtonProps {
    icon: React.ReactNode;
    text: string;
    mode: RecoveryMode;
    activeMode: RecoveryMode;
    onClick: (mode: RecoveryMode) => void;
}

const NavButton: React.FC<NavButtonProps> = ({ icon, text, mode, activeMode, onClick }) => {
    const isActive = mode === activeMode;
    return (
        <button 
            onClick={() => onClick(mode)}
            className={`flex items-center gap-3 p-3 rounded-lg text-left transition-all duration-200 ${
                isActive 
                ? 'bg-blue-500/20 text-blue-300 shadow-inner' 
                : 'text-slate-400 hover:bg-blue-500/10 hover:text-slate-200'
            }`}
        >
            <div className={`${isActive ? 'text-blue-400' : 'text-slate-500'}`}>{icon}</div>
            <span className="font-medium text-sm">{text}</span>
        </button>
    );
};

export default MainApplication;
