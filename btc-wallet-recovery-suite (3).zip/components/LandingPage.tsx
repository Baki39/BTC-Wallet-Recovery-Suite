/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import { Bot, KeyRound, BrainCircuit, Search, Download, ShieldCheck, Zap, Lock, Users } from 'lucide-react';

interface LandingPageProps {
  onLogin: () => void;
}

// TODO: Replace these placeholder URLs with your actual Stripe Payment Links.
// You can create these in your Stripe Dashboard under Products > Payment Links.
const STRIPE_MONTHLY_LINK = 'https://buy.stripe.com/your_monthly_link_here';
const STRIPE_YEARLY_LINK = 'https://buy.stripe.com/your_yearly_link_here';

const LandingPage: React.FC<LandingPageProps> = ({ onLogin }) => {
  return (
    <div className="h-screen max-h-screen antialiased bg-[#020617] text-[#E2E2E2] font-sans overflow-y-auto landing-page-scrollbar">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between p-4 bg-slate-900/50 backdrop-blur-sm border-b border-blue-900/50">
        <div className="flex items-center gap-3">
          <Bot size={28} className="text-blue-400" />
          <h1 className="text-xl font-bold text-white tracking-wider">BTC Wallet Recovery Suite</h1>
        </div>
        <div className="flex items-center gap-4">
          <button onClick={onLogin} className="text-sm font-semibold text-slate-300 hover:text-white transition-colors">Log In</button>
          <button onClick={onLogin} className="px-4 py-2 text-sm font-semibold text-white bg-blue-600 rounded-md hover:bg-blue-500 transition-colors">Sign Up</button>
        </div>
      </header>

      <main className="pt-20">
        {/* Hero Section */}
        <section className="relative text-center py-20 md:py-32 px-4 landing-hero">
            <div className="background-grid"></div>
            <div className="relative z-10">
                <h2 className="text-4xl md:text-6xl font-extrabold text-white leading-tight">
                    Unlock Your Lost Bitcoin.
                </h2>
                <h3 className="text-4xl md:text-6xl font-extrabold text-blue-400 leading-tight mt-2">
                    Your Memories Are The Key.
                </h3>
                <p className="max-w-3xl mx-auto mt-6 text-lg text-slate-400">
                    Our AI-powered suite acts as your personal crypto-archaeologist, transforming fragments of your memory into the patterns and passwords needed to recover your lost digital assets.
                </p>
                <div className="mt-8">
                    <button onClick={onLogin} className="px-8 py-3 font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-500 transition-transform transform hover:scale-105 shadow-lg">
                        Start Your Recovery Journey
                    </button>
                </div>
            </div>
        </section>

        {/* Features Section */}
        <section className="py-20 px-4 bg-slate-900/50">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h3 className="text-3xl font-bold text-white">Your Personal AI-Powered Recovery Toolkit</h3>
              <p className="mt-3 text-slate-400">A suite of powerful, specialized tools designed for one purpose: to get your assets back.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <FeatureCard
                icon={<KeyRound className="text-yellow-400" />}
                title="AI Decryption Engine"
                description="Load your encrypted wallet.dat file and let our AI generate & test thousands of password variations based on your clues, all securely within your browser."
              />
              <FeatureCard
                icon={<BrainCircuit className="text-purple-400" />}
                title="Seed Phrase Forensics"
                description="Got a partial or incorrect seed phrase? Our AI corrects typos, suggests missing words, and even provides guidance on complex derivation path issues."
              />
              <FeatureCard
                icon={<Search className="text-blue-400" />}
                title="AI Chain Investigator"
                description="Analyze any Bitcoin address to get an AI-generated forensic report. Uncover the likely wallet origin (e.g., Coinbase, Bitcoin Core) and get a personalized recovery path."
              />
               <FeatureCard
                icon={<Download className="text-green-400" />}
                title="System Recovery Scanner"
                description="Download a safe script to scan your entire computer for old wallet files, then upload the results to the Hub to begin your investigation immediately."
              />
            </div>
          </div>
        </section>

        {/* Security Section */}
        <section className="py-20 px-4">
            <div className="max-w-4xl mx-auto flex flex-col md:flex-row items-center gap-12">
                <div className="flex-shrink-0">
                    <ShieldCheck size={120} className="text-green-400"/>
                </div>
                <div>
                    <h3 className="text-3xl font-bold text-white">Security is Not an Afterthought. It's Our Foundation.</h3>
                    <p className="mt-4 text-slate-400">
                        We understand the sensitivity of what you're trying to recover. That's why our entire suite is built on a "zero-trust" principle.
                    </p>
                    <ul className="mt-4 space-y-2 text-slate-300">
                        <li className="flex items-start gap-3">
                            <Lock size={20} className="text-green-400 mt-1 shrink-0"/>
                            <span><strong>100% Client-Side Processing:</strong> All sensitive operations, including password testing and seed phrase validation, happen exclusively in your browser. Your files, phrases, and private data are never uploaded or exposed.</span>
                        </li>
                         <li className="flex items-start gap-3">
                            <Users size={20} className="text-green-400 mt-1 shrink-0"/>
                            <span><strong>No Private Key Handling:</strong> Our tools work with public addresses and encrypted files. We will never ask for, nor do we want, your private keys or full seed phrases.</span>
                        </li>
                    </ul>
                </div>
            </div>
        </section>

        {/* Pricing Section */}
        <section id="pricing" className="py-20 px-4 bg-slate-900/50">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h3 className="text-3xl font-bold text-white">Simple, Powerful Pricing</h3>
              <p className="mt-3 text-slate-400">One price for the complete toolkit. No hidden fees, no success fees.</p>
            </div>
            <div className="flex flex-col md:flex-row justify-center gap-8">
              <PricingCard
                plan="Monthly"
                price="$99.99"
                period="/month"
                description="Perfect for a focused, short-term recovery effort."
                features={["Full access to all AI tools", "Unlimited analysis & reports", "Cancel anytime"]}
                stripeUrl={STRIPE_MONTHLY_LINK}
              />
              <PricingCard
                plan="Yearly"
                price="$900.99"
                period="/year"
                description="For complex cases or multiple recoveries. Save over 20%!"
                features={["Full access to all AI tools", "Unlimited analysis & reports", "Priority support (coming soon)", "Best Value"]}
                stripeUrl={STRIPE_YEARLY_LINK}
                isFeatured
              />
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="py-8 text-center border-t border-blue-900/50">
            <p className="text-slate-500 text-sm">&copy; {new Date().getFullYear()} BTC Wallet Recovery Suite. All Rights Reserved.</p>
        </footer>
      </main>
    </div>
  );
};

const FeatureCard: React.FC<{ icon: React.ReactNode; title: string; description: string }> = ({ icon, title, description }) => (
    <div className="p-6 bg-slate-800/50 border border-blue-900/30 rounded-xl text-center feature-card">
        <div className="inline-block p-3 bg-slate-700/50 rounded-lg">
            {icon}
        </div>
        <h4 className="mt-4 text-lg font-semibold text-white">{title}</h4>
        <p className="mt-2 text-sm text-slate-400">{description}</p>
    </div>
);

const PricingCard: React.FC<{ plan: string; price: string; period: string; description: string; features: string[]; stripeUrl: string; isFeatured?: boolean }> = ({ plan, price, period, description, features, stripeUrl, isFeatured }) => {
    const handleSelect = () => {
        window.location.href = stripeUrl;
    };
    
    return (
    <div className={`p-8 border rounded-xl w-full max-w-sm pricing-card ${isFeatured ? 'border-blue-500 bg-slate-800/50' : 'border-slate-700 bg-slate-900'}`}>
        {isFeatured && <div className="text-center mb-4"><span className="px-3 py-1 text-xs font-semibold text-blue-300 bg-blue-500/20 rounded-full">Best Value</span></div>}
        <h4 className="text-xl font-bold text-center text-white">{plan}</h4>
        <div className="text-center my-4">
            <span className="text-4xl font-extrabold text-white">{price}</span>
            <span className="text-slate-400">{period}</span>
        </div>
        <p className="text-center text-sm text-slate-400 mb-6">{description}</p>
        <ul className="space-y-3 mb-8">
            {features.map((feature, index) => (
                <li key={index} className="flex items-center gap-3 text-sm text-slate-300">
                    <Zap size={16} className="text-green-400"/>
                    <span>{feature}</span>
                </li>
            ))}
        </ul>
        <button onClick={handleSelect} className={`w-full py-3 font-semibold rounded-lg transition-colors ${isFeatured ? 'bg-blue-600 text-white hover:bg-blue-500' : 'bg-slate-700 text-slate-200 hover:bg-slate-600'}`}>
            Choose {plan}
        </button>
    </div>
    );
};

export default LandingPage;