/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, MessageSender, LoadedFile, DecryptionProgress } from '../types';
import { generateDecryptionDictionary } from '../services/geminiService';
import ChatMessageItem from './ChatMessage';
import { Send, FileCheck2, Loader2, Play, AlertTriangle } from 'lucide-react';

interface WalletDatDecryptorProps {
    loadedFile: LoadedFile | null;
}

const WalletDatDecryptor: React.FC<WalletDatDecryptorProps> = ({ loadedFile }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [userQuery, setUserQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [decryptionProgress, setDecryptionProgress] = useState<DecryptionProgress>({ status: 'idle', log: [] });
  const consoleEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (loadedFile) {
      setMessages([
        {
          id: 'initial',
          sender: MessageSender.MODEL,
          text: `Great, the file **${loadedFile.name}** is ready. **It has not been uploaded anywhere.**\n\nNow, tell me any fragments you recall about the password. For example:\n\n*   A favorite word or name\n*   Important numbers or dates\n*   Special characters you often used`,
        }
      ]);
      setDecryptionProgress({ status: 'idle', log: [] });
    }
  }, [loadedFile]);

  const scrollToBottom = () => {
    consoleEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };
  useEffect(scrollToBottom, [messages, decryptionProgress.log]);

  const handleSendMessage = async () => {
    if (!userQuery.trim() || isLoading) return;
    const newUserMessage: ChatMessage = { id: `user-${Date.now()}`, text: userQuery, sender: MessageSender.USER };
    const updatedMessages = [...messages, newUserMessage];
    setMessages(updatedMessages);
    setUserQuery('');
    setIsLoading(true);

    try {
      const responseText = await generateDecryptionDictionary(updatedMessages);
      const newModelMessage: ChatMessage = { id: `model-${Date.now()}`, text: `I've generated a dictionary of potential passwords based on your clues. You can now start the automated decryption attempt.`, sender: MessageSender.MODEL };
      // We don't display the dictionary itself, just confirm it's ready.
      setMessages(prev => [...prev, newModelMessage]);
    } catch (e: any) {
      const errorMessage = e.message || 'An unknown error occurred.';
      setMessages(prev => [...prev, { id: `error-${Date.now()}`, text: `Error: ${errorMessage}`, sender: MessageSender.MODEL }]);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleStartDecryption = async () => {
    setDecryptionProgress({ status: 'generating', log: ['AI is generating a password dictionary...'] });
    
    try {
        const responseText = await generateDecryptionDictionary(messages);
        const { passwords } = JSON.parse(responseText);

        if (!passwords || passwords.length === 0) {
            setDecryptionProgress({ status: 'finished', log: [...decryptionProgress.log, 'AI could not generate passwords. Please provide more specific clues.'] });
            return;
        }

        setDecryptionProgress({ status: 'running', log: [`Starting decryption attempt on '${loadedFile?.name}' with ${passwords.length} passwords...`] });

        for (let i = 0; i < passwords.length; i++) {
            await new Promise(resolve => setTimeout(resolve, 100)); // Simulate work
            setDecryptionProgress(prev => ({ ...prev, log: [...prev.log, `[${i + 1}/${passwords.length}] Trying password: ${passwords[i]} ... FAILED`] }));
        }

        await new Promise(resolve => setTimeout(resolve, 300));
        setDecryptionProgress(prev => ({ ...prev, status: 'finished', log: [...prev.log, '\nDecryption attempt finished. No valid password found in this batch.'] }));

    } catch (e) {
        setDecryptionProgress({ status: 'finished', log: [...decryptionProgress.log, 'Error during decryption process. Please try again.'] });
    }
  };


  if (!loadedFile) {
    return (
        <div className="flex flex-col items-center justify-center h-full text-center p-8 bg-slate-800/50 border-2 border-dashed border-slate-700 rounded-xl">
            <AlertTriangle size={48} className="text-yellow-400 mb-4" />
            <h2 className="text-2xl font-bold mb-2 text-white">No Wallet File Loaded</h2>
            <p className="text-slate-400 mb-6 max-w-lg">Please go to the **Recovery Hub** to load a `wallet.dat` file before using the decryptor.</p>
        </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
        <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold text-white">AI-Powered Decryptor</h2>
            <div className="flex items-center gap-2 p-2 text-sm bg-green-900/50 text-green-300 border border-green-700/50 rounded-lg">
                <FileCheck2 size={16}/>
                <span>{loadedFile.name} loaded</span>
            </div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 flex-grow overflow-hidden">
            {/* Chat Column */}
            <div className="flex flex-col h-full bg-slate-800/50 border border-slate-700/50 rounded-lg p-4">
                <h3 className="text-lg font-bold text-white mb-2 shrink-0">1. Provide Clues</h3>
                <div className="flex-grow overflow-y-auto pr-2 chat-container -mr-2">
                    {messages.map((msg) => <ChatMessageItem key={msg.id} message={msg} />)}
                    {isLoading && <ChatMessageItem message={{ id: 'loading', sender: MessageSender.MODEL, text: '...', isLoading: true }} />}
                    <div ref={consoleEndRef} />
                </div>
                <div className="pt-4 mt-2 border-t border-blue-900/50">
                    <div className="flex items-center gap-3">
                        <textarea
                            value={userQuery}
                            onChange={(e) => setUserQuery(e.target.value)}
                            placeholder="e.g., used my dog's name 'rex'..."
                            className="flex-grow h-10 min-h-[40px] py-2 px-3 border border-slate-700 bg-slate-900 text-slate-200 placeholder-slate-500 rounded-lg focus:ring-2 focus:ring-blue-500 resize-none text-sm"
                            rows={1}
                            disabled={isLoading || decryptionProgress.status === 'running'}
                            onKeyPress={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage(); }}}
                        />
                        <button onClick={handleSendMessage} disabled={isLoading || !userQuery.trim() || decryptionProgress.status === 'running'} className="h-10 w-10 p-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-colors disabled:bg-slate-700 disabled:text-slate-400 flex items-center justify-center flex-shrink-0" aria-label="Send message">
                           <Send size={20} />
                        </button>
                    </div>
                </div>
            </div>

            {/* Decryption Column */}
            <div className="flex flex-col h-full bg-slate-800/50 border border-slate-700/50 rounded-lg p-4">
                <h3 className="text-lg font-bold text-white mb-2">2. Start Automated Decryption</h3>
                <p className="text-sm text-slate-400 mb-4">After providing clues, the AI will generate a password dictionary. Start the automated process to test them against your file locally.</p>
                <button
                    onClick={handleStartDecryption}
                    disabled={decryptionProgress.status === 'running' || decryptionProgress.status === 'generating' || messages.length === 0}
                    className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-500 text-white font-semibold rounded-md transition-colors disabled:bg-slate-700 disabled:text-slate-400 disabled:cursor-not-allowed"
                >
                    {decryptionProgress.status === 'running' || decryptionProgress.status === 'generating' ? <><Loader2 size={20} className="animate-spin" /> Running...</> : <><Play size={20} /> Start Decryption Attempt</>}
                </button>
                <div className="mt-4 flex-grow bg-black/50 rounded-md p-3 overflow-y-auto chat-container">
                     <p className="text-xs text-slate-400 font-mono mb-2">Decryption Console (Simulation)</p>
                    <pre className="text-xs text-green-400 font-mono whitespace-pre-wrap">
                        {decryptionProgress.log.map((line, i) => <div key={i}>{`> ${line}`}</div>)}
                    </pre>
                    <div ref={consoleEndRef} />
                </div>
            </div>
        </div>
    </div>
  );
};

export default WalletDatDecryptor;