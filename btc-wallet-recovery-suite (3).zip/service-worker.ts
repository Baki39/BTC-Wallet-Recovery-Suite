/// <reference lib="webworker" />
// FIX: Removed redundant declaration of 'self'. The 'webworker' lib reference already defines it.

const CACHE_NAME = 'btc-recovery-suite-cache-v1';
const urlsToCache = [
  '/',
  '/index.html',
  '/index.css',
  '/index.tsx',
  '/App.tsx',
  '/components/LandingPage.tsx',
  '/components/MainApplication.tsx',
  '/components/RecoveryHub.tsx',
  '/components/SystemScanner.tsx',
  '/components/WalletDatDecryptor.tsx',
  '/components/PasswordRecovery.tsx',
  '/components/SeedPhraseRecovery.tsx',
  '/components/FindWalletGuide.tsx',
  '/components/ChainInvestigator.tsx',
  '/components/EducationCenter.tsx',
  '/components/ChatMessage.tsx',
  '/components/TransactionTimeline.tsx',
  '/services/geminiService.ts',
  '/types.ts',
  'https://cdn.tailwindcss.com',
  'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/atom-one-dark.min.css',
  'https://esm.sh/@google/genai@^1.0.1',
  'https://esm.sh/react@^19.1.0',
  'https://esm.sh/react-dom@^19.1.0/',
  'https://esm.sh/marked@^13.0.2',
  'https://esm.sh/lucide-react@^0.417.0',
  'https://esm.sh/highlight.js@^11.9.0',
  'https://esm.sh/bip39@3.1.0',
  '/icons/icon-192x192.png',
  '/icons/icon-512x512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Opened cache');
        return cache.addAll(urlsToCache);
      })
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        // Cache hit - return response
        if (response) {
          return response;
        }

        // Clone the request because it's a stream and can only be consumed once.
        const fetchRequest = event.request.clone();

        return fetch(fetchRequest).then(
          (response) => {
            // Check if we received a valid response
            if (!response || response.status !== 200 || response.type !== 'basic' && response.type !== 'cors') {
              return response;
            }

            // Clone the response because it's a stream and can only be consumed once.
            const responseToCache = response.clone();

            caches.open(CACHE_NAME)
              .then((cache) => {
                // We don't cache API calls to Gemini
                if (!event.request.url.includes('generativelanguage.googleapis.com')) {
                   cache.put(event.request, responseToCache);
                }
              });

            return response;
          }
        );
      })
  );
});

self.addEventListener('activate', (event) => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});
